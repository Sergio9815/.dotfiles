### CHANGELOG

#### Version 0.1.2

* remove no needed dependency form config window

#### Version 0.1.1

* support latest libraries from Latte git version

#### Version 0.1.0

* option to choose icon that will be used
* option to choose the maximum icon size
* option to choose sidebar based on screen edge, name and latte layout

